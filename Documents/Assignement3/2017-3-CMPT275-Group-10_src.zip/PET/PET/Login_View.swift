//
//  ViewController.swift
//  PET
//
//  Created by Wolf on 2017-10-18.
//  Copyright © 2017 TEAMX. All rights reserved.
//

// IMPORT FRAMWORKS
import UIKit
import FirebaseAuth
import FirebaseDatabase

// Class: Login_View
// Members:
//          1. Text labels
//          2. Text fields
//          3. login button
//          4. sign up button
// Description:
class Login_View: UIViewController
{
    // Reference to Database
    var ref: DatabaseReference!
    
    // Do any additional setup after loading the view, typically from a nib.
    override func viewDidLoad(){
        super.viewDidLoad()
        // Load Reference to Firebase Database
        ref = Database.database().reference()
    }
    
    // TEXT FIELD FOR LOGIN SCREEN
    @IBOutlet weak var textField_username: UITextField!
    @IBOutlet weak var textField_passowrd: UITextField!
    
    // TEXT LABEL FOR ERROR
    // *** ADD in pop up Error later ***
    @IBOutlet weak var Lable_LoginError: UILabel!
    
    // Initialize User Object
    let userload = User_Model(ID: "uid", name: "", age: 1, gender: "", email: "", password: "", progress: ProgressArray(useriD: "", emotionIn: Constants.emoIDArray ,StateIn: Constants.stateIDArray))
    
    // UI Component: LOGIN BUTTON
    // Activated: When Pressed
    // Action: Perform Auth.auth() account authentication -> Redirect user to Main Menu
    @IBAction func button_login(_ sender: UIButton){
        
        if let email = textField_username.text, let password = textField_passowrd.text {
            // Firebase Authentication Function
            // Pre-Req: Internet connection must be vaild *** CHECKING NEED TO BE IMPLEMENTED ***
            // Input:
            //      1. withEmail: email -> user email for account
            //      2. password: password -> User password for account
            //      3. completion: {user, error in} -> Checks for error such as proper email address + password vaild
            // Ouput:
            //      1. Signin Successful: message to terminal (Print to screen)
            //      2. Signin Unsuccessful: message to terminal (Print to screen)
            Auth.auth().signIn(withEmail: email, password: password, completion: {user, error in
                
                // IF LOGIN ERROR OCCURS PRINT ERROR MESSAGE
                if let firebaseError = error {
                    self.Lable_LoginError.text = "Incorrect Username or Password"
                    print(firebaseError.localizedDescription)
                }
                    // Successful login
                else {
                    // LOAD USER UID FROM FIREBASE.AUTH()
                    let user1 = Auth.auth().currentUser!
                    let uid = user1.uid;
                    
                    // Set user UID from firebase into local user object
                    self.userload.ID = uid
                    self.userload.progress.userID = uid
                    
                    // LOAD FUNCTIONS FROM DATABASE
                    self.loadAccInfo(ID: uid, obj: self.userload)
                    self.loadProgress(ID: uid, obj: self.userload, tiers: TIER_SIZE, numQ: Q_PER_TIER)
                    self.performSegue(withIdentifier: "segLogin", sender: self)
                }
            })
        }
    }
    
    // UI Component: SIGN UP BUTTON
    // Activated: When Pressed
    // Action: Perform Segue "seg_create" -> Redirect user into acccount creation view
    @IBAction func button_signUp(_ sender: Any){
        self.performSegue(withIdentifier: "seg_create", sender: self)
    }
    
    // Function: Load Account information from firebase database if login successful
    // Input:
    //      1. ID: String -> user ID
    //      2. obj: User_Model -> User object
    // Ouput: N/A
    func loadAccInfo(ID: String, obj: User_Model) {
        
        // From reference of DB load ROOT -> Contains all user tables
        // observeSingleEvent: View value under table once
        // snapshot: NSOBJECT for data structure viewed
        self.ref.child("ROOT").child(ID).observeSingleEvent(of: .value, with: { snapshot in
            
            // Load snapshot table from DB values as NS type
            let NSname = snapshot.childSnapshot(forPath: "Name").value as? NSString!
            let NSage = snapshot.childSnapshot(forPath: "Age").value as? NSString!
            let Sage = NSage as? String ?? ""
            let NSgender = snapshot.childSnapshot(forPath: "Gender").value as? NSString!
            let NSemail = snapshot.childSnapshot(forPath: "Email").value as? NSString!
            let NSpassword = snapshot.childSnapshot(forPath: "Password").value as? NSString!
            // let UIDP = snapshot.children
            // let NSshotSize = snapshot.childrenCount
            
            // Casting NSString into String and store into user object
            obj.name = NSname as? String ?? ""
            obj.age = Int(Sage)!
            obj.gender = NSgender as? String ?? ""
            obj.email = NSemail as? String ?? ""
            obj.password = NSpassword as? String ?? ""
        })
    }
    
    // Function: Load Progress Array from firebase database and store into local user object
    // Input:
    //      1. ID: String -> user ID
    //      2. obj: User_Model -> User object
    //      3. tiers: Int -> Tier or level number (indexed from 0 to 4)
    //      4. numQ: Int -> Question number (indexed from 0 to 9)
    // Ouput: N/A
    func loadProgress(ID: String, obj: User_Model, tiers: Int, numQ: Int) {
        
        //Counter for indexing purposes
        var counter = 0
        
        // Double for loop for traversing though progess array
        // i = tier/level index
        // j = question index
        for i in 0..<tiers{
            for j in 0..<numQ{
                
                // Create set question name for question in database for seaching
                let A = String(i); let B = String(j)
                let Qname = A + B
                
                // From reference of DB load ROOT -> Contains all user tables
                // observeSingleEvent: View value under table once
                // snapshot: NSOBJECT for data structure viewed
                self.ref.child("ROOT").child(ID).child("Progress").child(Qname).observeSingleEvent(of: .value, with: { snapshot in
                    
                    //Search State of question under
                    let NSstate = snapshot.childSnapshot(forPath: "State").value as? NSNumber
                    
                    //Set State of qusetion (Load from DB, Store into local user object)
                    let InState = NSstate?.intValue
                    if InState == 3 {obj.progress.questionArray[counter].questionState = .skipped }
                    else if InState == 2 {obj.progress.questionArray[counter].questionState = .incorrect }
                    else if InState == 1 {obj.progress.questionArray[counter].questionState = .correct }
                    else { obj.progress.questionArray[counter].questionState = .initial}
                    
                    //Set Error counter of qusetion (Load from DB, Store into local user object)
                    let NSerrCnt = snapshot.childSnapshot(forPath: "ErrCnt").value as? NSNumber
                    obj.progress.questionArray[counter].errCnt = (NSerrCnt?.intValue)!
                    obj.progress.questionArray[counter].imageFileRef = Constants.ImageNameArray[counter]
                    
                    counter += 1
                })
            }
        }
    }
    
    // Function: overrider prepare() to allow for sending of variables to other view controllers
    // Input:
    //      1. for segue: UIStoryboardSegue
    //      2. sender: Any
    // Ouput: N/A
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let send_user = userload
        if let destinationViewController = segue.destination as? Main_menu {
            destinationViewController.user = send_user
        }
    }
}
