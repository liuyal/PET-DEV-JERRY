//
//  LevelSelect_View.swift
//  PET
//
//  Created by liuyal on 10/29/17.
//  Copyright © 2017 TEAMX. All rights reserved.
//

// IMPORT FRAMWORKS
import UIKit
import FirebaseAuth
import FirebaseDatabase

// Class: LevelSelect_View
// Members:
//          1. text fields
//          2. text labels
//          3. back button
//          4. create account button
// Description:
class LevelSelect_View: UIViewController {
    
    // Passed in User object
    var user: User_Model?
 
    // Variable for tier detection
    var selected_Tier: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // **** LOAD BUTTONS TO INDICATE FINISHED ****
        // **** TODO ****
    }
    
    // UI Component: Selection Button
    // Activated: When Pressed
    // Action: Will redirect to selected page when pressed
    @IBAction func LevelButton(_ sender: UIButton) {
        selected_Tier = sender.tag
        
        /// ****** FOR 2 levels only update with tier for later ******
        if selected_Tier > 1 {selected_Tier = 1; }
        print(selected_Tier)
        
        self.performSegue(withIdentifier: "segQSelect", sender: self)
    }
    @IBAction func FFButton(_ sender: UIButton) {
         self.performSegue(withIdentifier: "segFF", sender: self)
    }
    @IBAction func QBankButton(_ sender: UIButton) {
         self.performSegue(withIdentifier: "segQBank", sender: self)
    }
    @IBAction func Main_menuBack(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segPlayBack", sender: self)
    }
    
    // Function: overrider prepare() to allow for sending of variables to other view controllers
    // Input:
    //      1. for segue: UIStoryboardSegue
    //      2. sender: Any
    // Ouput: N/A
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let send_user = user
        if let destinationViewController = segue.destination as? Main_menu {
            destinationViewController.user = send_user
        }
        else if let destinationViewController = segue.destination as? QSelect_View {
            destinationViewController.user = send_user
             destinationViewController.tierNum = selected_Tier
        }
        else if let destinationViewController = segue.destination as? FacialFun_View {
            destinationViewController.user = send_user
        }
        else if let destinationViewController = segue.destination as? QBank_View {
            destinationViewController.user = send_user
        }
    }
}
