//
//  Setting_View.swift
//  PET
//
//  Created by Wolf on 2017-10-19.
//  Copyright © 2017 TEAMX. All rights reserved.
//

// IMPORT FRAMWORKS
import UIKit
import FirebaseAuth
import FirebaseDatabase

// Class: Setting_View
// Members:
//          1.
//          2.
//          3.
//          4.
// Description:
class Setting_View: UIViewController {
    
    //Reference to FireDataBase
    var ref: DatabaseReference!
    
    // User object for passing of object between views
    var user: User_Model?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Load Reference to Firebase Database
        ref = Database.database().reference()
    }
    
    
    
    
    
    
    
    
    // ******** TO BE ADDED ********
    
    
    
    
    
    
    
    
    
    // UI Component: Return to Main Menu BUTTON
    // Activated: When Pressed
    // Action: Perform segue  "segSettingBack" to Main menu
    @IBAction func Main_menuBack(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segSettingBack", sender: self)
    }

    // Function: overrider prepare() to allow for sending of variables to other view controllers
    // Input:
    //      1. for segue: UIStoryboardSegue
    //      2. sender: Any
    // Ouput: N/A
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let send_user = user
        if let destinationViewController = segue.destination as? Main_menu {
            destinationViewController.user = send_user
        }
    }
    
}
