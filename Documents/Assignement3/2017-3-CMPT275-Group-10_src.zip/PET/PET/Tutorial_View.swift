//
//  Tutorial_View.swift
//  PET
//
//  Created by Wolf on 2017-10-19.
//  Copyright © 2017 TEAMX. All rights reserved.
//

// IMPORT FRAMWORKS
import UIKit
import FirebaseAuth
import FirebaseDatabase

// Class: Tutorial_View
// Members:
//          1.
//          2.
//          3.
//          4.
// Description:
class Tutorial_View: UIViewController {
    
    //Reference to FireDataBase
    var ref: DatabaseReference!
    
    // User object for passing of object between views
    var user: User_Model?
    
    @IBOutlet weak var currentImage: UIImageView!
    @IBOutlet weak var currentText: UITextView!
    
    var Counter:Int = 0
    // Image array
    // Index 0: Level Selection
    //       1: Question Selection
    //       2: Question
    //       3: Question Updated (wrong)
    //       4: Next Question
    //       5: Question Updated (correct)
    //       5: Question Selection Updated
    let imageArray:[UIImage] = [#imageLiteral(resourceName: "Level_Select"),#imageLiteral(resourceName: "Question_Select"),#imageLiteral(resourceName: "Question_Initial"),#imageLiteral(resourceName: "Question_Updated"),#imageLiteral(resourceName: "Question"),#imageLiteral(resourceName: "Question_Correct"),#imageLiteral(resourceName: "Updated_Question_Select")]
    // Text array
    let textArray:[String] = ["Welcome to Tutorial! Here is Level Select, you can choose which level of questions you want to play. Facial Fun and Question Bank are awesome features which we will be releasing in Version 2 and 3! Click 'Next' to see what's in Level 1", "These are the questions in Level 1, and you can select where you want to start. Once you have gotten a question right, it will be blacked out to indicate complete. Click 'Next' to play!", "Here is an example question, if you answer wrong the answer will be blacked out. Click 'Next' to see!", "Here is the question after you got the wrong answer, with the answer selected blacked out. Click 'Next' to go to a different question!", "Here is another question, let's see what happens when you get the right answer!", "Here we see the question after you got it right! There is a star in the top left corner now! Click 'Next' to see the updated Question Selection View", "Here is the updated Question Selection View, now you see that you completed Question 1! Click 'Main Menu' to start playing!"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Load the first image in
        currentImage.image = imageArray[Counter]
        currentText.text = textArray[Counter]
    }
    
    @IBAction func clicked_bNext(_ sender: UIButton) {
        
        // Index the array up to load next image
        // Counter = Counter + 1
        // Check to see if the counter has passed the max size of the images
        if (Counter < imageArray.count-1) {
            // Load the image & text
            currentImage.image = imageArray[Counter + 1]
            currentText.text = textArray[Counter + 1]
            self.Counter += 1
        }
        else {
            // If its further than the max size of the imageArray, reduce the counter
            Counter = Counter - 1
        }
    }
    
    @IBAction func clicked_bBack(_ sender: UIButton) {
        
        if (Counter > 0) {
            currentImage.image = imageArray[Counter - 1]
            currentText.text = textArray[Counter - 1]
            self.Counter -= 1
        }
        else {
            Counter = 0
        }
    }
    // UI Component: Return to Main Menu BUTTON
    // Activated: When Pressed
    // Action: Perform segue  "segTutBack" to Main menu
    @IBAction func Main_menuButton(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segTutBack", sender: self)
    }
    
    // Function: overrider prepare() to allow for sending of variables to other view controllers
    // Input:
    //      1. for segue: UIStoryboardSegue
    //      2. sender: Any
    // Ouput: N/A
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let send_user = user
        if let destinationViewController = segue.destination as? Main_menu {
            destinationViewController.user = send_user
        }
    }
}

