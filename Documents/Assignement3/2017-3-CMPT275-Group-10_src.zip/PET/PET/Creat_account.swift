//
//  Creat_account.swift
//  PET
//
//  Created by Wolf on 2017-10-18.
//  Copyright © 2017 TEAMX. All rights reserved.
//

// IMPORT FRAMWORKS
import UIKit
import FirebaseAuth
import FirebaseDatabase

// Class: Creat_account
// Members:
//          1. text fields
//          2. text labels
//          3. back button
//          4. create account button
// Description:
class Creat_account: UIViewController{
    
    //Reference to FireDataBase
    var ref: DatabaseReference!
    
    // Create User Object
    let CreateUser = User_Model(ID: "uid", name: "", age: 1, gender: "", email: "", password: "", progress: ProgressArray(useriD: "", emotionIn: Constants.emoIDArray ,StateIn: Constants.stateIDArray));
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.age_field.keyboardType = UIKeyboardType.numberPad
        
        // Load Reference to Firebase Database
        ref = Database.database().reference()
        
        let font = UIFont.systemFont(ofSize: 18)
        sege.setTitleTextAttributes([NSAttributedStringKey.font: font], for: .normal)
        }
    
    //Input fields for user and account information
    @IBOutlet weak var fullname_field: UITextField!
    @IBOutlet weak var age_field: UITextField!
    @IBOutlet weak var sege: UISegmentedControl!
    @IBOutlet weak var name_field: UITextField!
    @IBOutlet weak var passwd_field: UITextField!
    @IBOutlet weak var confirmPW_field: UITextField!

    //Labels For ERROR Messages
    @IBOutlet weak var ErrorLabel: UILabel!

    // UI Component: Gender Segement Selection
    // Activated: When Pressed
    // Action: Base of index print to consol (Debug purpose) -> ** DO NOT SET VALUE **
    @IBAction func segeValueChange(_ sender: UISegmentedControl) {
        if sege.selectedSegmentIndex == 0 {print("Male")}
        else if sege.selectedSegmentIndex == 1 {print("Female")}
    }
    
    // UI Component: Create Account button
    // Activated: When Pressed
    // Action: Check all inputs for errror, attempt to create account via Auth.auth().createUser, If successful -> redirect user to main menu
    @IBAction func button_Create_ACC(_ sender: UIButton) {
        
        // Flag for correct inputs from text fields
        var ACCcheck = false
        var Infocheck = false
        
        //INFOCHECK: Check input for 1st 3 parameters, name(STRING), Age(Int), Gender(Bool)
        if let fullname = fullname_field.text, let age = age_field.text {
          
            //Check for Empty fields or fields with only space, return, and/or tab characters
            if fullname.trimmingCharacters(in: .whitespaces).isEmpty || age.trimmingCharacters(in: .whitespaces).isEmpty {
                Infocheck = false
                
                // *** Print to screen to be added ***
                 print("EMPTY NAME or Age")
            }
            else {
                // Check for age is integer between 0 to 99
                if let ageint = Int(age) {
                    if (ageint >= 1 && ageint <= 99) {Infocheck = true}
                    else{print("Invaild Age");Infocheck = false}}
                else {print("Invaild Age"); Infocheck = false}
                // *** Print to screen to be added ***
            }
        }
        
        //ACCCHECK: Check input for last 3 parameters
        if let email = name_field.text, let password = passwd_field.text, let confirmPW = confirmPW_field.text {
            
            //Check if password = confirm password, and email fields are empty
            if confirmPW == password && (confirmPW != "" && password != "") && email != "" {ACCcheck = true}
            else {print("PW ERROR") }
            // *** Print to screen to be added ***
            
            // All inputs are vaild and correct -> Attempt to create user via Auth.auth().createUser
            // Invaild inputs will NOT be able to reach functions under this condition
            if ACCcheck == true && Infocheck == true{
                
                // Firebase Authentication Function
                // Pre-Req: Internect connection must be vaild **** CHECKING NEED TO BE IMPLEMENTED ****
                // Input:
                //      1. withEmail: email -> user email for account
                //      2. password: password -> User password for account
                //      3. completion: {user, error in} -> Checks for error such as proper email address + password vaild
                // Ouput:
                //      1. Create Successful: message to terminal (Print to screen)
                //      2. Create Unsuccessful: message to terminal (Print to screen)
                Auth.auth().createUser(withEmail: email, password: password) { (user, error) in
                    
                     // IF Account create ERROR occurs PRINT ERROR MESSAGE
                    if let firebaseError = error {
                        print(firebaseError.localizedDescription)
                        self.ErrorLabel.text = firebaseError.localizedDescription
                        ACCcheck = false
                    }
                    else {
                        // Update User Object * search ID first *
                        let user1 = Auth.auth().currentUser!
                        let uid = user1.uid;
                        
                        // Check segement and load gender as STRING
                        var Ingen: String = ""
                        if self.sege.selectedSegmentIndex == 0 {  Ingen = "Male"}
                        else {  Ingen = "Female"}
                        
                        // Update user Object
                        self.updateUserObj(userObj: self.CreateUser, ID: uid, fullname: self.fullname_field.text!, age: Int(self.age_field.text!)!, gender: Ingen, mail: self.name_field.text!, pw: self.passwd_field.text!)
                        
                        // Add personal info to database, Add account info to database under node: ROOT (Sorted by UID)
                        self.CreateUserInDataBase(ID: uid, name: self.fullname_field.text!, age: self.age_field.text!, gender: Ingen, mail: self.name_field.text!, pw: self.passwd_field.text!)
                      
                        // Add progress array to databse
                        self.CreateProgressDB (obj: self.CreateUser, id: uid, tiers: TIER_SIZE, numQ: Q_PER_TIER)
                        
                        // *** ADD POP UP LATER ***
                        print("Create Accound Good")
                        self.performSegue(withIdentifier: "seg_createGood", sender: self)
                    }
                }
            }
            else {self.ErrorLabel.text = "Account Information Incorrect"}
        }
    }
    // Function: Update Local User Object
    // Input:
    //      1. userObj: User_Model -> User object
    //      2. ID: String -> user ID
    //      3. fullname: String -> Full name of user
    //      4. age: Int -> age of user
    //      5. gender: String -> User object
    //      6. mail: String -> user email
    //      7. pw: String -> user account password
    // Ouput: N/A
    func updateUserObj(userObj: User_Model, ID: String, fullname: String, age: Int, gender: String, mail: String, pw: String){
        userObj.ID = ID;
        userObj.name = fullname
        userObj.age = age
        userObj.gender = gender
        userObj.email = mail
        userObj.password = pw
        userObj.progress.userID = ID
        userObj.print_user()
    }
    
    // Function: Create User table in Firebase database under ROOT using inputs provided below
    // Pre-Req: Internet connection must be vaild *** CHECKING NEED TO BE IMPLEMENTED ***
    // Input:
    //      1. ID: String -> user ID
    //      2. fullname: String -> Full name of user
    //      3. age: Int -> age of user
    //      4. gender: String -> User object
    //      5. mail: String -> user email
    //      6. pw: String -> user account password
    // Ouput: N/A
    func CreateUserInDataBase(ID: String, name: String, age: String, gender: String, mail: String, pw: String){
        self.ref.child("ROOT").child(ID).setValue(nil)
        self.ref.child("ROOT").child(ID).child("UID").setValue(ID)
        self.ref.child("ROOT").child(ID).child("Name").setValue(name)
        self.ref.child("ROOT").child(ID).child("Age").setValue(age)
        self.ref.child("ROOT").child(ID).child("Gender").setValue(gender)
        self.ref.child("ROOT").child(ID).child("Email").setValue(mail)
        self.ref.child("ROOT").child(ID).child("Password").setValue(pw)
        self.ref.child("ROOT").child(ID).child("Progress").setValue(nil)
    }
    
    // Function: Create User progress array table in Firebase database under ROOT->UID(unique) using inputs provided below
    // Pre-Req: Internet connection must be vaild *** CHECKING NEED TO BE IMPLEMENTED ***
    // Input:
    //      1. userObj: User_Model -> User object
    //      2. id: String -> user ID
    //      3. tiers: Int -> number of tiers/level in game
    //      4. numQ: String -> number of question per tiers/level in game
    // Ouput: N/A
    // Suggestion: *** Globle variable to replace tiers: Int, and NumQ:Int ***
    func CreateProgressDB (obj: User_Model, id: String, tiers: Int, numQ: Int){
      
        //counter for indexing purposes
        var counter = 0
        
        // State of question, stored as int in database
        var Instate: Int = 0
     
        // Double for loop for traversing though progess array
        // i = tier/level index
        // j = question index
        for i in 0..<tiers{
            for j in 0..<numQ{
                
                // Update emotion ID base on ID ARRAYbase
                let err = Int(obj.progress.questionArray[counter].errCnt)
                let A = String(i); let B = String(j)
                let Qname = A + B
                
                //Set State of qusetion (Load from local user object, Store into DB)
                if obj.progress.questionArray[counter].questionState == .skipped {  Instate = 3 }
                else if obj.progress.questionArray[counter].questionState == .incorrect {  Instate = 2 }
                else if obj.progress.questionArray[counter].questionState == .correct { Instate = 1}
                else { Instate = 0}
                
                //Set State and errorcount of qusetion (Load from local user object, Store into DB)
                self.ref.child("ROOT").child(id).child("Progress").child(Qname).child("State").setValue(Instate)
                self.ref.child("ROOT").child(id).child("Progress").child(Qname).child("ErrCnt").setValue(err)
                counter += 1
            }
        }
    }

    // Function: overrider prepare() to allow for sending of variables to other view controllers
    // Input:
    //      1. for segue: UIStoryboardSegue
    //      2. sender: Any
    // Ouput: N/A
   override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let send_user = self.CreateUser
        if let destinationViewController = segue.destination as? Main_menu {
            destinationViewController.user = send_user
        }
    }
}
