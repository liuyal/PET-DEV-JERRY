//
//  Constants.swift
//  PET
//
//  Created by liuyal on 10/29/17.
//  Copyright © 2017 TEAMX. All rights reserved.
//

import Foundation

struct Constants {
    
    //static let ImageArray = "TEST"
    static let EmotionNameArray: [String] = ["happy", "sad", "angry", "scared","happy", "sad", "angry", "scared","happy", "sad", "angry","scared", "happy", "sad", "angry","scared", "happy", "sad", "angry", "scared"]
    
    static let ImageNameArray: [String] = ["00_happy", "01_sad", "02_angry", "03_scared","04_happy", "05_sad", "06_angry", "07_scared", "08_happy", "09_sad", "10_angry", "11_scared","12_happy", "13_sad", "14_angry", "15_scared","16_happy", "17_sad", "18_angry", "19_scared"]
    
    static let emoIDArray: [emotionID] = [.happy, .sad, .angry, .scared,.happy, .sad, .angry, .scared, .happy, .sad, .angry, .scared,.happy, .sad, .angry, .scared,.happy, .sad, .angry, .scared]
    
    static let stateIDArray: [state] = [.initial,.initial,.initial,.initial,.initial,.initial,.initial,.initial,.initial,.initial,.initial,.initial,.initial,.initial,.initial,.initial,.initial,.initial,.initial,.initial]
}
