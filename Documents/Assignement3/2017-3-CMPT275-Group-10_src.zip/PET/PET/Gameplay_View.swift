//
//  Gameplay_View.swift
//  PET
//
//  Created by liuyal on 10/29/17.
//  Copyright © 2017 TEAMX. All rights reserved.
//

// IMPORT FRAMWORKS
import UIKit
import FirebaseAuth
import FirebaseDatabase

// Class: Gameplay_View
// Members:
//          1.
//          2.
//          3.
//          4.
// Description:
class Gameplay_View: UIViewController {
    
    // Passed in data or object variables
    var ref: DatabaseReference!
    var user: User_Model?
    
    var tierNum: Int?
    var Qnum: Int? // 0-9
    var index: Int? // 0-19
    
    // Array on image Literals **** If expanded will need to be in Constants() ****
    // ***** Need to fit to UIImageLabel better *****
    let imageArray: [UIImage] = [#imageLiteral(resourceName: "00_happy"),#imageLiteral(resourceName: "01_sad"),#imageLiteral(resourceName: "02_angry"),#imageLiteral(resourceName: "03_scared"),#imageLiteral(resourceName: "04_happy"),#imageLiteral(resourceName: "05_sad"),#imageLiteral(resourceName: "06_angry"),#imageLiteral(resourceName: "07_scared"),#imageLiteral(resourceName: "08_happy"),#imageLiteral(resourceName: "09_sad"),#imageLiteral(resourceName: "10_angry"),#imageLiteral(resourceName: "11_scared"),#imageLiteral(resourceName: "12_happy"),#imageLiteral(resourceName: "13_sad"),#imageLiteral(resourceName: "14_angry"),#imageLiteral(resourceName: "15_scared"),#imageLiteral(resourceName: "16_happy"),#imageLiteral(resourceName: "17_sad"),#imageLiteral(resourceName: "18_angry"),#imageLiteral(resourceName: "19_scared")]
    let starInid: [UIImage] = [#imageLiteral(resourceName: "Star0"),#imageLiteral(resourceName: "Star1")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Reference to database
        ref = Database.database().reference()
 
         // Upon loading of page set title to selected level
        let titleN = QuizNum.text as String?
        let StringNum = String(Qnum! + 1)
        let newTitle = titleN?.replacingOccurrences(of: "#", with: StringNum, options: .literal, range: nil)
        print(newTitle!)
        QuizNum.text = newTitle!
        
        //load index of quesiton within the progress array
        index = tierNum! * 10 + Qnum!
        
        //LOAD STAR ****N eed to Scale/ Find better icon ****
        if user?.progress.questionArray[index!].questionState == .correct{StateStar.image = starInid[1]}
        else { StateStar.image = starInid[0]}
        
        // LOAD IMAGE base on index of progress array
        QuestionImage.image = imageArray[tierNum! * 10 + Qnum!]
        
        message.text = ""
    }

    // Lables to UIImageView and text Labels
    @IBOutlet weak var StateStar: UIImageView!
    @IBOutlet weak var QuestionImage: UIImageView!
    @IBOutlet weak var QuizNum: UILabel!
    @IBOutlet weak var message: UILabel!
    
    // UI Component: Any selection button
    // Activated: When Pressed
    // Action: Detect the value of the button pressed and process selection
    @IBAction func Action(_ sender: UIButton) {
        
         print(sender.tag)
        var selected: emotionID = .happy
        if sender.tag == 10 { selected = .happy}
        else if sender.tag == 1{ selected = .sad}
        else if sender.tag == 2{ selected = .angry}
        else if sender.tag == 3{ selected = .scared}
        else if sender.tag == 4{
            // If skipped is selected
            if user?.progress.questionArray[index!].questionState != .correct{
                var nextIndex = Qnum!
                //Look for next question which the state is anything but correct and load page accordingly
                for _ in 0..<Q_PER_TIER{
                    nextIndex += 1
                    if nextIndex >= Q_PER_TIER{ nextIndex = 0 }
                    if user?.progress.questionArray[tierNum! * 10 + nextIndex].questionState != .correct{
                        user?.progress.questionArray[index!].questionState = .skipped
                        self.updateProgressDB()
                        // REload images and texts
                        self.updatePage(indexx: nextIndex)
                        return
                    }
                    if tierNum! * 10 + nextIndex == index {
                        print ("All Level Complete")
                        self.performSegue(withIdentifier: "segGameplayBack", sender: self)}
                }
            }
            else {
                // Skip to next question if question is completed
                //self.updateProgressDB()
                var nextIndex = Qnum! + 1
                if nextIndex >= Q_PER_TIER{nextIndex = 0}
                self.updatePage(indexx: nextIndex)
                return
            }
        }
        
        // if selection is correct
        if selected == user?.progress.questionArray[index!].emotion {
            // Change question state to correct
            user?.progress.questionArray[index!].questionState = .correct;
            // Update database for progression
            self.updateProgressDB()
            var counter = self.Qnum!
            
            //Look for next question which the state is anything but correct and load page accordingly
            for _ in 0..<Q_PER_TIER{
                counter += 1;  print(counter)
                if counter >= Q_PER_TIER{ counter = 0 }
                if user?.progress.questionArray[tierNum! * 10 + counter].questionState != .correct{
                    self.updateProgressDB()
                     // REload images and texts
                    self.updatePage(indexx: counter)
                    break
                }
                // All levels completed return to question select
                if tierNum! * 10 + counter == index {
                    print ("All Level Complete")
                    self.performSegue(withIdentifier: "segGameplayBack", sender: self)}
            }
        }
        else if selected != user?.progress.questionArray[index!].emotion && user?.progress.questionArray[index!].questionState != .correct{
            
            let tempButton = self.view.viewWithTag(sender.tag) as? UIButton
            tempButton?.backgroundColor =  UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.5)
            
            user?.progress.questionArray[index!].questionState = .incorrect
            user?.progress.questionArray[index!].errCnt += 1
            self.updateProgressDB()
            print("ERROR")
            message.text = "Try Again"
        }
        else {}
    }
    
    // UI Component: Return to Level select button
    // Activated: When Pressed
    // Action: Return to level selection page
    @IBAction func backbutton(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segGameplayBack", sender: self)
    }
    
    // Function: Update User progression table for errcnt and state in Firebase database under ROOT
    // Pre-Req: Internet connection must be vaild *** CHECKING NEED TO BE IMPLEMENTED ***
    // Input: N/A
    // Ouput: N/A
    func updateProgressDB() {
        self.user?.progress.update_total_CompRate()
        let id = self.user?.ID
        var Instate: Int
        let err = self.user?.progress.questionArray[self.index!].errCnt
        let A = String(tierNum!); let B = String(Qnum!)
        let Qname = A + B
        
        if self.user?.progress.questionArray[self.index!].questionState == .skipped {  Instate = 3 }
        else if self.user?.progress.questionArray[self.index!].questionState == .incorrect {  Instate = 2 }
        else if self.user?.progress.questionArray[self.index!].questionState == .correct { Instate = 1}
        else { Instate = 0}
        
        self.ref.child("ROOT").child(id!).child("Progress").child(Qname).child("State").setValue(Instate)
        self.ref.child("ROOT").child(id!).child("Progress").child(Qname).child("ErrCnt").setValue(err)
       // print( user?.progress.questionArray[index!].levelID,user?.progress.questionArray[index!].questionID as any)
    }
    
    // Function: Update Gameplay page with the next question to be play
    // Pre-Req: N/A
    // Input: indexx -> index of page to be loaded 0-9
    // Ouput: N/A
    func updatePage(indexx: Int){
        print ("correct")
        //sleep(1) // OUTPUT TO SCreen
        // LOAD TITLE
        let titleN = "Quiz "
        let StringNum = String(indexx+1)
        QuizNum.text = titleN + StringNum; print(QuizNum.text!)
        //LOAD STAR ****Need to Scale****
        if self.user?.progress.questionArray[indexx + (tierNum!*10)].questionState == .correct
        { self.StateStar.image = starInid[1]}
        else { self.StateStar.image = starInid[0]}
        QuestionImage.image = imageArray[tierNum! * 10 + indexx]
        self.Qnum! = indexx
        self.index! = indexx + (tierNum!*10)
        
        let tempButton0 = self.view.viewWithTag(10) as? UIButton
        tempButton0?.backgroundColor =  UIColor(red: 0.847, green: 0.35686, blue: 0.53333, alpha: 1.0)
        let tempButton1 = self.view.viewWithTag(1) as? UIButton
        tempButton1?.backgroundColor =  UIColor(red: 0.847, green: 0.35686, blue: 0.53333, alpha: 1.0)
        let tempButton2 = self.view.viewWithTag(2) as? UIButton
        tempButton2?.backgroundColor =  UIColor(red: 0.847, green: 0.35686, blue: 0.53333, alpha: 1.0)
        let tempButton3 = self.view.viewWithTag(3) as? UIButton
        tempButton3?.backgroundColor =  UIColor(red: 0.847, green: 0.35686, blue: 0.53333, alpha: 1.0)
        
        message.text = ""
    }
    
    // Function: overrider prepare() to allow for sending of variables to other view controllers
    // Input:
    //      1. for segue: UIStoryboardSegue
    //      2. sender: Any
    // Ouput: N/A
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let send_user = user
        let send_tier = tierNum
        if let destinationViewController = segue.destination as? QSelect_View {
            destinationViewController.user = send_user
            destinationViewController.tierNum = send_tier
        }
    }
}

